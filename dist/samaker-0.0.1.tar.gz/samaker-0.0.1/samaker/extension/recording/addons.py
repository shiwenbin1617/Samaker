from samaker.extension.recording.recording import Record


addons = [Record('baba.yaml', save_response=True, save_headers=False)]
    